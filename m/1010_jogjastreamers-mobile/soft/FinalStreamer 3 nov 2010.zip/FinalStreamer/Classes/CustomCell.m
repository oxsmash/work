//
//  CustomCell.m
//  CustomCellTestProject
//
//  Created by Citraweb Nusa Infomedia on 10/27/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CustomCell.h"


@implementation CustomCell
@synthesize primaryLabel,secondaryLabel,myImageView;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
	
	if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
		
		// Initialization code
		
		primaryLabel = [[UILabel alloc]init];
		primaryLabel.textAlignment = UITextAlignmentLeft;
		primaryLabel.font = [UIFont systemFontOfSize:20];
		primaryLabel.textColor = [UIColor whiteColor];
		primaryLabel.backgroundColor = [UIColor clearColor];
		primaryLabel.opaque = NO;  
		primaryLabel.textAlignment = UITextAlignmentRight;

		
		secondaryLabel = [[UILabel alloc]init];
		secondaryLabel.textAlignment = UITextAlignmentLeft;
		secondaryLabel.font = [UIFont systemFontOfSize:14];
		secondaryLabel.textColor = [UIColor whiteColor];
		secondaryLabel.backgroundColor = [UIColor clearColor];
		secondaryLabel.opaque = NO;  
		secondaryLabel.textAlignment = UITextAlignmentRight;
		
		myImageView = [[UIImageView alloc]init];
		
		[self.contentView addSubview:primaryLabel];
		[self.contentView addSubview:secondaryLabel];
		[self.contentView addSubview:myImageView];
		
		//------------------------------------
		//UILabel* label = [[UILabel alloc] init];
		//label.frame = CGRectMake( 20, 10, 200, 22 );
		//label.text = @"your text here:";
		//[cell addSubview:label];
		//[label release];
		//------------------------------------
		
	}	
	
	return self;
	
}

- (void)layoutSubviews {
	
	[super layoutSubviews];
	
	CGRect contentRect = self.contentView.bounds;
	CGFloat boundsX = contentRect.origin.x;
	
	CGRect frame;
	
	frame= CGRectMake(boundsX+10 ,boundsX+10, 70, 70);
	myImageView.frame = frame;
	
	frame= CGRectMake(boundsX+70 ,17, 210, 25);
	primaryLabel.frame = frame;
	
	frame= CGRectMake(boundsX+70 ,37, 210, 25);
	secondaryLabel.frame = frame;
	
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
	
	[super setSelected:selected animated:animated];
	
	// Configure the view for the selected state
	
}

- (void)dealloc {
	[primaryLabel release];
	[secondaryLabel release];
	[myImageView release];
	[super dealloc];
}

@end
