//
//  CustomCell.h
//  CustomCellTestProject
//
//  Created by Citraweb Nusa Infomedia on 10/27/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CustomCell : UITableViewCell {

	UILabel *primaryLabel;

	UILabel *secondaryLabel;
	
	UIImageView *myImageView;
	
}

@property(nonatomic,retain)UILabel *primaryLabel;

@property(nonatomic,retain)UILabel *secondaryLabel;

@property(nonatomic,retain)UIImageView *myImageView;

@end
