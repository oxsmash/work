//
//  test_navigateAppDelegate.m
//  test navigate
//
//  Created by Citraweb Nusa Infomedia on 10/7/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "test_navigateAppDelegate.h"
#import "RootViewController.h"
#import "XMLParser.h"	//xml parser - fungsi yang menterjemahkan xml

@implementation test_navigateAppDelegate

@synthesize window;
@synthesize navigationController, books;


#pragma mark -
#pragma mark Application lifecycle

//menjalankan saat aplikasi load pertama kali
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
	// Override point for customization after app launch    
	
	/*--[ load XML pertama kali load ]-----------------*/
	//menginisialisasi fungsi web iphone
	NSURL *url = [[NSURL alloc] initWithString:@"http://www.jogjastreamers.com/tes.xml"];
	//load web ke parser
	NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url];
	
	//Initialize the delegate.
	XMLParser *parser = [[XMLParser alloc] initXMLParser];
	
	//Set delegate
	[xmlParser setDelegate:parser];
	
	//Start parsing the XML file.
	BOOL success = [xmlParser parse];
	
	if(success)
		NSLog(@"No Errors");
	else
		NSLog(@"Error Error Error!!!");
	/*------------------------------------------------*/
	
	[window addSubview:[navigationController view]];
    [window makeKeyAndVisible];
	return YES;
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[books release];
	[navigationController release];
	[window release];
	[super dealloc];
}


@end

