//
//  test_navigateAppDelegate.h
//
//  Created by Citraweb Nusa Infomedia on 10/7/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface test_navigateAppDelegate : NSObject <UIApplicationDelegate> {
    //header untuk memanggil root view controller
    UIWindow *window;
    UINavigationController *navigationController;
	
	//inisialisasi aray untuk memanggil isi XML
	NSMutableArray *books;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@property (nonatomic, retain) NSMutableArray *books;

@end

