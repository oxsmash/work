//
//  ViewTwoController.h
//  NavApp
//
//  Created by Wess Cope on 3/23/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

//load class untuk XML dan Streamers
@class AudioStreamer;
@class Book;

@interface ViewTwoController : UIViewController {
	IBOutlet UILabel *label;
	IBOutlet UITextField *downloadSourceField;
	IBOutlet UIButton *button;
		
	AudioStreamer *streamer;
	Book *aBook;
}
@property (nonatomic, retain) Book *aBook;
@property (nonatomic, retain) UILabel *label;

- (IBAction)buttonPressed:(id)sender;
- (void)spinButton;
- (void)updateProgress:(NSTimer *)aNotification;
- (IBAction)sliderMoved:(UISlider *)aSlider;

@end
