//
//  RootViewController.h
//  test navigate
//
//  Created by Citraweb Nusa Infomedia on 10/7/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class test_navigateAppDelegate, ViewTwoController;
//load class variable untuk XML
@class Book;

@interface RootViewController : UITableViewController {
	test_navigateAppDelegate *appDelegate;
	ViewTwoController *bdvController;
	
	Book *aBook;
}
@property (nonatomic, retain) Book *aBook;

@end
