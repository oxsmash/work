//
//  RootViewController.m
//  test navigate
//
//  Created by Citraweb Nusa Infomedia on 10/7/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "test_navigateAppDelegate.h"
#import "RootViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ViewTwoController.h"
#import "Book.h"
#import "CustomCell.h"

@implementation RootViewController

@synthesize aBook;

#pragma mark -
#pragma mark View lifecycle

//yang di lakukan ketika view muncul
- (void) viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
}

- (void)viewDidLoad {
	//---set the title--- 
    self.navigationItem.title = @"JogjaStreamers";
	
	[super viewDidLoad];
	appDelegate = (test_navigateAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	self.title = @"Jogja Streamers";
	
	// membikin clear background
	//self.tableView.backgroundColor = [UIColor clearColor];

	// background pattern image
	//self.tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"playbutton.png"]];
	
	// color image
	//self.tableView.backgroundColor = [UIColor redColor];
}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //return [self.drinks count];
	return [appDelegate.books count];
}

//mengatur ukuran tinggi cell
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 76;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
	// default cell definition
    /*UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] 
				 //initWithStyle:UITableViewCellStyleDefault 
				 initWithFrame:CGRectZero
				 reuseIdentifier:CellIdentifier] autorelease];
    }*/
	
	// custom cell
	CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[CustomCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    }
    
	Book *aBook = [appDelegate.books objectAtIndex:indexPath.row];
	
	// Configure the cell
	
	// Configure the background color cell
	//cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"a.png"]];
	//cell.textLabel.backgroundColor = [UIColor clearColor];

	// membuat efek lengkung pada cell
	//cell.imageView.layer.masksToBounds = YES;
	//cell.imageView.layer.cornerRadius = 5.0;
	
	// menghapus spasi pada string XML yang di parser untuk judul
	NSString *trimmedTitle = [aBook.title stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	NSString *trimmedTitle2 = [aBook.title2 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	// load text to cell
	//--cell.text = trimmedTitle;
	//cell.textColor = [UIColor whiteColor];
	/*--[custom cell class] --------------------------------------------*/
	cell.primaryLabel.text = trimmedTitle;
	cell.secondaryLabel.text = @"1XX FM";
	//--cell.secondaryLabel.text = trimmedTitle2;
	//cell.myImageView.image = [UIImage imageNamed:@"a.png"];
	/*--[end custom cell class] --------------------------------------------*/
	// clear text background maker
	for ( UIView* view in cell.contentView.subviews ) 
	{
		view.backgroundColor = [ UIColor clearColor ];
	}
	
	// menghapus spasi pada string XML yang di parser untuk gambar
	NSString *trimmedPic = [aBook.summary stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	NSURL *myURL = [[NSURL alloc] initWithString:trimmedPic];
	//NSURL *myURL = [[NSURL alloc] initWithString:@"http://www.jogjastreamers.com/iphpic/Ardia.png"];
	UIImage *myImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:myURL]];
	//x-NSImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSUrl NSURL URLWithString:MyURL]]];
	// load image to cell
	//cell.image = myImage;
	//cell.imageView.image = myImage;
	
	// setting posisi image
	/*[cell.imageView setBounds:CGRectMake(0, 0, 0, 0)];
	[cell.imageView setClipsToBounds:NO];
	[cell.imageView setFrame:CGRectMake(0, 0, 0, 0)];
	[cell.imageView setContentMode:UIViewContentModeScaleAspectFill];*/
	
	// clear background color set
	//cell.backgroundColor = [UIColor clearColor];
	//cell.textLabel.backgroundColor = [UIColor clearColor];
	
	// gambr background default
	
	// testing gambar
	//--NSURL *myURL = [[NSURL alloc] initWithString:@"http://www.google.co.id/intl/en_com/images/srpr/logo1w.png"];
	//UIImage *myImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:myURL]];
	
	//--UIImage *myImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:myURL]];
	
	//[imageView3 setImage:resultingImage];
	UIImageView *imageView = [[UIImageView alloc] initWithImage:myImage];
	imageView.contentMode = UIViewContentModeScaleToFill;
	cell.backgroundView = imageView;
	
	// standart from web
	/*UIImage *image = [UIImage imageNamed:@"gradientcolor.png"];
	UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
	imageView.contentMode = UIViewContentModeScaleToFill;
	cell.backgroundView = imageView;
	[imageView release];
	
	UILabel *label = [[UILabel alloc] init];
	label.text = @"testing colors";
	label.frame = cell.bounds;
	label.backgroundColor = [UIColor clearColor];
	label.textAlignment = UITextAlignmentCenter;
	[cell addSubview:label];*/	
	
	// gambr background saat di klik
	//cell.selectedBackgroundView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"a.png"]] autorelease];
	//cell.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:@"a.png"]stretchableImageWithLeftCapWidth:320 topCapHeight:44]];
	
	// tanda panah ke halaman berikut nya standar apple;
	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	//static background color
	//self.parentViewController.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"a.png"]];
	self.tableView.separatorColor = [UIColor clearColor];
	self.tableView.backgroundColor = [UIColor clearColor];
	
	//log to check
	//NSLog(aBook.summary);
	return cell;
	
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Pass the selected object to the new view controller.
	if(bdvController == nil)
		bdvController = [[ViewTwoController alloc] 
						 //load halaman saat cell di klik
						 initWithNibName:@"View2" 
						 bundle:[NSBundle mainBundle]];

	Book *aBook = [appDelegate.books objectAtIndex:indexPath.row];
	bdvController.aBook = aBook;
	
	[self.navigationController pushViewController:bdvController animated:YES];
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)dealloc {
	[bdvController release];
	[appDelegate release];
    [super dealloc];
}

//--[still unused]-------------------------------------------------------------------
- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

/*
 - (void)viewWillAppear:(BOOL)animated {
 [super viewWillAppear:animated];
 }
 */
/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */
// Override to allow orientations other than the default portrait orientation.
/*- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }*/

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

//-----------------------------------------------------------------------------------

@end

