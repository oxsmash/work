<?
//ob_start();
session_start();
include("../inc/fungsi.php");
include("../inc/config.php");

$cKode=utk5Digit(rand(1,32768));
$crypt = new MD5Crypt;
$hKode = $crypt->Encrypt($cKode,key_generator);

if (!isset($_SESSION["radioSession"])) {
	$_SESSION['radioSession'] = $hKode;
	$_SESSION['sessionCode'] = $cKode;
}

$rs=mysql_query("select * from cni_streamer where status='1' and id='1'");
$row=mysql_fetch_array($rs);
$cuplikan=putusKalimat($row[isi],300);
$idwelcome = $row[id];


$sqlMerapi2 = "SELECT * FROM ".cni_berita." where status_berita=1 ORDER BY berita_id DESC limit 3";
$resMerapi2 = mysql_query($sqlMerapi2);

// $folderNya="images/banner/";
/*$sql_text = "select * from ".cni_banner." where status_banner='1' and letak_banner='3' group by banner_id DESC limit 4";

$sql=mysql_query($sql_text);*/

if(!empty($_GET['play'])) {

	$cmd100 =   "INSERT INTO statistik(id_radio,tgl,referer,ip) 
			VALUES(
				'".$_GET['play']."',
				now(),
				'".$_SERVER['HTTP_REFERER']."',
				'".$_SERVER['REMOTE_ADDR']."'
			)";
	//'".date("Y-m-d h:i:s")."',
	
	
	//mysql_query($cmd100) or die();
	
	setStatistik($_GET['play']);

}

$timeHariIni = date("Y-m-d");
							
	//echo $timeHariIni;

$cmdBannerBawah = "SELECT * FROM cni_banner 
				WHERE letak_banner = '2' 
				AND status_banner = '1' 
				AND (selesai_banner >= '".$timeHariIni."'   
					AND mulai_banner <= '".$timeHariIni."')
				AND (limit_banner > jumlah_show)
				AND tgl_show = '".$timeHariIni."'   
				ORDER BY rand() 
				
				
				";

//echo $cmdBannerBawah;

$resBannerBawah = mysql_query($cmdBannerBawah);		

if(mysql_num_rows($resBannerBawah) < 1) {

	$cmdUpdate1 = "UPDATE cni_banner SET 
					jumlah_show = '0',
					tgl_show = '".$timeHariIni."' 
					WHERE tgl_show < '".$timeHariIni."' 
						";
					
					
	mysql_query($cmdUpdate1);	
}
?>

<table>
<tr>
	<td>
		<br><br>
		<span class="hijau f-georgia f-20">Berita Jogjastreamers</span><br>
		<ul class="markiri0 padkiri0">
		<?php
			while($rsMerapi2=mysql_fetch_assoc($resMerapi2)){
				echo "<li class='putih padlist'><a class='abu pointer' onclick=loadBeritaDetail('".$rsMerapi2[berita_id]."'); >".$rsMerapi2[judul_berita]."</a></li>";
			
			}
		
		?>
	</td>
</tr>
</table>